#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/* @author: zhoujian
 * @qq: 2025513
 * @create-time: ${DATE} ${TIME}
 * @description: 
 * @version: 1.0
 * @finished: false
 * @finished-time: 
 */
public enum ${NAME} {
}
